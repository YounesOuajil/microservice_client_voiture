package com.abs.abs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
