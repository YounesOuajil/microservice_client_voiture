package com.abs.abs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbsApplication.class, args);
	}

}
