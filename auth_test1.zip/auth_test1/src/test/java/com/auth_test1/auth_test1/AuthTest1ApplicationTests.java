package com.auth_test1.auth_test1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthTest1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
