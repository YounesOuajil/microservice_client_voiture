package com.auth_test1.auth_test1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(AuthTest1Application.class, args);
	}

}
