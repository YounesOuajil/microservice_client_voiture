package com.auth_test2.auth_test2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthTest2Application {

	public static void main(String[] args) {
		SpringApplication.run(AuthTest2Application.class, args);
	}
}
