package com.auth_test1.auth_test2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthTest2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
