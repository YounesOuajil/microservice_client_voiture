package com.ecomapp.productserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductserverApplication.class, args);
	}

}
